﻿using System;
using System.Linq;

namespace LinqWithObjects
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var names = new string[] { "Aswin", "Sample2", "Sample3", "Sample4", "Aswin2", "Sample5", "Sample6", "Sample7" };
            var query = names.Where(new Func<string, bool>(NameLongerThanFour));
            foreach(string item in query)
            {
                Console.WriteLine(item);
            }
            var querywithoutdelegatequery = names.Where(NameLongerThanFour);
            Console.WriteLine("querywithoutdelegatequery");
            foreach (string item in querywithoutdelegatequery)
            {
                Console.WriteLine(item);
            }
            var querywithlambdaexpression = names.Where(name => name.Length > 4);
            Console.WriteLine("querywithlambdaexpression");
            foreach (string item in querywithlambdaexpression)
            {
                Console.WriteLine(item);
            }

            var querywithlambdaexpressionorderby = names
                .Where(name => name.Length > 4)
                .OrderBy(name => name.Length);
            Console.WriteLine("querywithlambdaexpressionorderby");
            foreach (string item in querywithlambdaexpressionorderby)
            {
                Console.WriteLine(item);
            }
            var querywithlambdaexpressionorderbythenby = names
                .Where(name => name.Length > 4)
                .OrderBy(name => name.Length)
                .ThenBy(name => name);
            Console.WriteLine("querywithlambdaexpressionorderbythenby");
            foreach (string item in querywithlambdaexpressionorderbythenby)
            {
                Console.WriteLine(item);
            }
        }
        static bool NameLongerThanFour(string name)
        {
            return name.Length > 5;
        }
    }
}
